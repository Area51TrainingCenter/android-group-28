package area51.videoplayer;

/**
 * Created by segundo on 14/01/17.
 */

public class VideoPlayerGlobals {

    public static String LOG = "VIDEO_PLAYER";
    public static String FRESCO_CACHE = "VIDEO_PLAYER";


}
