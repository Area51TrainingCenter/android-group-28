package area51.videoplayer.screens.player.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import area51.videoplayer.R;

public class VideoPlayerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
    }
}
