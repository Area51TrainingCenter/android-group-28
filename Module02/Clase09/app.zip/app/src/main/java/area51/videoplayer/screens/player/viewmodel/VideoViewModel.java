package area51.videoplayer.screens.player.viewmodel;

/**
 * Created by segundo on 21/01/17.
 */

public class VideoViewModel {
}
